package com.spa.smart_parking_assistance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartParkingAssistanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartParkingAssistanceApplication.class, args);
	}

}
