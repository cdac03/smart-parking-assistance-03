package com.spa.smart_parking_assistance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartParkingAssistanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
